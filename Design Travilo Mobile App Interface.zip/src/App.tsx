import { TopNav } from './components/TopNav';
import { MapSection } from './components/MapSection';
import { TransitList } from './components/TransitList';
import { BottomNav } from './components/BottomNav';

export default function App() {
  return (
    <div className="h-screen w-full max-w-md mx-auto bg-gray-50 flex flex-col">
      {/* Top Navigation */}
      <TopNav />

      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto">
        {/* Map Section */}
        <MapSection />

        {/* Transit List */}
        <TransitList />
      </div>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  );
}
