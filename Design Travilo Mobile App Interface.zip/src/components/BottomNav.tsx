import { Home, Route, Bell, User } from 'lucide-react';

export function BottomNav() {
  const navItems = [
    { icon: Home, label: 'Home', active: true },
    { icon: Route, label: 'Routes', active: false },
    { icon: Bell, label: 'Alerts', active: false },
    { icon: User, label: 'Profile', active: false },
  ];

  return (
    <div className="bg-white border-t border-gray-100 px-6 py-3 shadow-lg">
      <div className="flex items-center justify-between">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.label}
              className="flex flex-col items-center gap-1 px-4 py-1"
            >
              <Icon
                className={`w-5 h-5 ${
                  item.active ? 'text-blue-500' : 'text-gray-400'
                }`}
              />
              <span
                className={`text-xs ${
                  item.active ? 'text-blue-500' : 'text-gray-400'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
