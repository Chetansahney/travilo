import { Navigation } from 'lucide-react';

export function MapSection() {
  const stations = [
    { id: 1, name: 'Central Station', crowd: 'low', top: '25%', left: '30%' },
    { id: 2, name: 'City Mall', crowd: 'high', top: '45%', left: '65%' },
    { id: 3, name: 'University', crowd: 'medium', top: '60%', left: '40%' },
    { id: 4, name: 'Airport Link', crowd: 'low', top: '35%', left: '70%' },
    { id: 5, name: 'Park Ave', crowd: 'medium', top: '70%', left: '25%' },
  ];

  const getCrowdColor = (crowd: string) => {
    switch (crowd) {
      case 'low':
        return 'bg-green-500';
      case 'medium':
        return 'bg-yellow-500';
      case 'high':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <div className="relative bg-gradient-to-br from-gray-50 to-blue-50/30 rounded-3xl mx-4 mt-4 overflow-hidden shadow-md">
      {/* Map background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `
            linear-gradient(to right, #cbd5e1 1px, transparent 1px),
            linear-gradient(to bottom, #cbd5e1 1px, transparent 1px)
          `,
          backgroundSize: '30px 30px'
        }}></div>
      </div>

      <div className="relative h-64 p-4">
        {/* Current location indicator */}
        <div className="absolute top-4 left-4 bg-blue-500 rounded-full p-2 shadow-lg">
          <Navigation className="w-4 h-4 text-white" />
        </div>

        {/* Station markers */}
        {stations.map((station) => (
          <div
            key={station.id}
            className="absolute transform -translate-x-1/2 -translate-y-1/2"
            style={{ top: station.top, left: station.left }}
          >
            <div className="relative group cursor-pointer">
              {/* Pulse animation for current selection */}
              {station.id === 1 && (
                <div className={`absolute inset-0 ${getCrowdColor(station.crowd)} rounded-full animate-ping opacity-75`}></div>
              )}
              
              {/* Station dot */}
              <div className={`relative w-6 h-6 ${getCrowdColor(station.crowd)} rounded-full border-3 border-white shadow-lg`}></div>
              
              {/* Station label */}
              <div className="absolute top-8 left-1/2 -translate-x-1/2 bg-white px-2 py-1 rounded-lg shadow-md opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                <span className="text-xs">{station.name}</span>
              </div>
            </div>
          </div>
        ))}

        {/* Route lines */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          <line x1="30%" y1="25%" x2="65%" y2="45%" stroke="#3b82f6" strokeWidth="2" strokeDasharray="5,5" opacity="0.3" />
          <line x1="65%" y1="45%" x2="40%" y2="60%" stroke="#3b82f6" strokeWidth="2" strokeDasharray="5,5" opacity="0.3" />
        </svg>

        {/* Legend */}
        <div className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-sm rounded-xl p-2 shadow-md">
          <div className="flex gap-3 text-xs">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span className="text-gray-600">Low</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
              <span className="text-gray-600">Med</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-red-500 rounded-full"></div>
              <span className="text-gray-600">High</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
