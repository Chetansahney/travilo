import { Clock, Users, TrendingDown, Bus, Train } from 'lucide-react';

interface Transit {
  id: number;
  type: 'bus' | 'train';
  route: string;
  destination: string;
  eta: string;
  crowdLevel: 'low' | 'medium' | 'high';
  alternative?: {
    route: string;
    eta: string;
    savings: string;
  };
}

export function TransitList() {
  const transits: Transit[] = [
    {
      id: 1,
      type: 'train',
      route: 'Blue Line',
      destination: 'Downtown',
      eta: '3 min',
      crowdLevel: 'high',
      alternative: {
        route: 'Express 45',
        eta: '8 min',
        savings: '60% less crowded',
      },
    },
    {
      id: 2,
      type: 'bus',
      route: 'Route 32',
      destination: 'University',
      eta: '5 min',
      crowdLevel: 'medium',
    },
    {
      id: 3,
      type: 'train',
      route: 'Green Line',
      destination: 'Airport',
      eta: '12 min',
      crowdLevel: 'low',
    },
    {
      id: 4,
      type: 'bus',
      route: 'Route 18',
      destination: 'City Mall',
      eta: '15 min',
      crowdLevel: 'low',
    },
  ];

  const getCrowdColor = (level: string) => {
    switch (level) {
      case 'low':
        return { bg: 'bg-green-50', text: 'text-green-700', icon: '🟢' };
      case 'medium':
        return { bg: 'bg-yellow-50', text: 'text-yellow-700', icon: '🟡' };
      case 'high':
        return { bg: 'bg-red-50', text: 'text-red-700', icon: '🔴' };
      default:
        return { bg: 'bg-gray-50', text: 'text-gray-700', icon: '⚪' };
    }
  };

  return (
    <div className="px-4 pb-4 space-y-4">
      <div className="flex items-center justify-between pt-4">
        <h2 className="text-gray-900">Nearby Transit</h2>
        <span className="text-sm text-gray-500">Live updates</span>
      </div>

      <div className="space-y-3">
        {transits.map((transit) => {
          const crowdStyle = getCrowdColor(transit.crowdLevel);
          const TypeIcon = transit.type === 'bus' ? Bus : Train;

          return (
            <div key={transit.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-4">
                <div className="flex items-start gap-3">
                  {/* Icon */}
                  <div className={`p-2 ${transit.type === 'bus' ? 'bg-blue-50' : 'bg-green-50'} rounded-xl`}>
                    <TypeIcon className={`w-5 h-5 ${transit.type === 'bus' ? 'text-blue-500' : 'text-green-500'}`} />
                  </div>

                  {/* Content */}
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-gray-900">{transit.route}</h3>
                        <p className="text-sm text-gray-500 mt-0.5">{transit.destination}</p>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4 text-gray-400" />
                          <span className="text-gray-900">{transit.eta}</span>
                        </div>
                      </div>
                    </div>

                    {/* Crowd level */}
                    <div className="flex items-center gap-2 mt-3">
                      <span className="text-sm">{crowdStyle.icon}</span>
                      <span className={`text-sm ${crowdStyle.text} capitalize`}>
                        {transit.crowdLevel} crowd
                      </span>
                      <Users className={`w-4 h-4 ${crowdStyle.text}`} />
                    </div>
                  </div>
                </div>

                {/* Alternative suggestion */}
                {transit.alternative && (
                  <div className="mt-3 pt-3 border-t border-gray-100">
                    <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-xl p-3">
                      <div className="flex items-center gap-2 mb-1">
                        <TrendingDown className="w-4 h-4 text-green-600" />
                        <span className="text-sm text-gray-700">Less crowded alternative</span>
                      </div>
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-sm text-gray-900">{transit.alternative.route}</span>
                        <span className="text-sm text-gray-500">{transit.alternative.eta}</span>
                      </div>
                      <div className="mt-1">
                        <span className="text-xs text-green-700">{transit.alternative.savings}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
