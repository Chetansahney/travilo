import { Search } from 'lucide-react';

export function TopNav() {
  return (
    <div className="bg-white border-b border-gray-100 px-4 py-3 shadow-sm">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-green-500 rounded-xl flex items-center justify-center">
            <span className="text-white font-bold">T</span>
          </div>
          <span className="font-semibold text-gray-900">Travilo</span>
        </div>
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Enter destination"
            className="w-full pl-10 pr-4 py-2 bg-gray-50 rounded-full border-none outline-none focus:ring-2 focus:ring-blue-500/20"
          />
        </div>
      </div>
    </div>
  );
}
