
  # Design Travilo Mobile App Interface

  This is a code bundle for Design Travilo Mobile App Interface. The original project is available at https://www.figma.com/design/xhF3gkvK7VLhuS5f0WPNn4/Design-Travilo-Mobile-App-Interface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  